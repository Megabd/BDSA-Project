# Assignment 02

* Group 1: wihe, hecn, frai
* Group 2: lanr, weny, emkh
* Group 3: emno, siol, jacg
* Group 4: adjr, aguh, fefa
* Group 5: rogy, luel, skas
* Group 6: ojoh, asly, tuho
* Group 7: phla, okre, sibh
* Group 8: jric, mfjo, rasni
* Group 9: kbej, jklo, crco
* Group 10: midf, stmp, ehel
* Group 11: laup, avia, annro
* Group 12: monha, tbru, kmey
* Group 13: otja, nlje, aing
* Group 14: nihp, amdh, jwni
* Group 15: frjo, json, behv
* Group 16: mhsi, atro, hcan
* Group 17: reer, laku, frepe
* Group 18: ahad, aldy, tuka
* Group 19: mhvl, jawb, luha
* Group 20: tcla, olfw, hast
* Group 21: mesv, lufr, nicha
* Group 22: pekp, bemi, chbl
* Group 23: emtj, dlha, base
* Group 24: aarv, mbia, brml
* Group 25: mbln, mwha, malsc
* Group 26: memr, mgan, labp
* Group 27: mreh, tosp, siar
* Group 28: jakst, lawu, tbav
* Group 29: vime, tokj, jouj
* Group 30: dadh, shho, nkar
* Group 31: mbjn, rafa, mlth
* Group 32: frhc, selb, adrka
* Group 33: vist, unla, mroa
* Group 34: gues, erja, rakt
* Group 35: eikb, phimo, ssbo
* Group 36: clly, asjo, nkrj
* Group 37: elbr, frgm, biha
* Group 38: bath, raoo, kmsa
* Group 39: oljh, maxt, bhag
* Group 40: clwj, nsel, paab, oska
* Group 41: aegr, millh, timj
* Group 42: shad, ksig, jown
* Group 43: seel, omac, nidd
* Group 44: husa, noms, esmi
* Group 45: jevb, teim, tael, asgm
