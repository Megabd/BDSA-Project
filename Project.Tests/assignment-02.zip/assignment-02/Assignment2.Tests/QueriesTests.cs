namespace Assignment2.Tests;

public class QueriesTests
{
    [Fact]
    public void Test1()
    {

    }
}
