﻿foreach (var wizard in WizardCollection.Create())
{
    Console.WriteLine(wizard);
}
