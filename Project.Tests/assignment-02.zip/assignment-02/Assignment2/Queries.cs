namespace Assignment2;

public class Queries
{
}
